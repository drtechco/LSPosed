#pragma once

namespace danlant::art {
class ValueObject {};
}  // namespace danlant::art
