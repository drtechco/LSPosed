# DexBuilder

c++ dex builder for replacement with [dexmaker](https://github.com/linkedin/dexmaker).

Most of them are copied from [AOSP](https://cs.android.com/android/platform/superproject/+/master:frameworks/base/startop/view_compiler).

Modified parts are owed by LSPosed Developers. If you would like to use it in an open source project, please submodule it.

Only part of instructions used by LSPosed are implemented. If you want to add other instructions, PR is welcomed.
